/*
 * max30102.h
 *
 *  Created on: Nov 26, 2025
 *      Author: sreer
 */

#ifndef MAX30102_H_
#define MAX30102_H_


#include <stdint.h>

// I2C Slave Address (The MAX30102 has one fixed address)
#define MAX30102_ADDR 0xAE

// --- Register Map Definitions ---
#define REG_INTR_STATUS_1       0x00
#define REG_INTR_STATUS_2       0x01
#define REG_INTR_ENABLE_1       0x02
#define REG_INTR_ENABLE_2       0x03
#define REG_FIFO_WR_PTR         0x04
#define REG_OVF_COUNTER         0x05
#define REG_FIFO_RD_PTR         0x06
#define REG_FIFO_DATA           0x07
#define REG_FIFO_CONFIG         0x08
#define REG_MODE_CONFIG         0x09
#define REG_SPO2_CONFIG         0x0A
#define REG_LED_CONFIG          0x0C
#define REG_TEMP_INTR           0x1F
#define REG_TEMP_FRAC           0x20
#define REG_REV_ID              0xFE
#define REG_PART_ID             0xFF // Should read 0x15

// --- Mode Configuration Register Bits (REG_MODE_CONFIG, 0x09) ---
#define MODE_SHUTDOWN       (1 << 7)
#define MODE_RESET          (1 << 6)
#define MODE_HR_ONLY        (0x02)
#define MODE_SPO2_EN        (0x03)
#define MODE_MULTI_LED_EN   (0x07)

// --- FIFO Config Register Bits (REG_FIFO_CONFIG, 0x08) ---
// Sample Averaging
#define FIFO_SAMPLE_AVE_1   (0x00 << 5)
#define FIFO_SAMPLE_AVE_8   (0x02 << 5)
#define FIFO_SAMPLE_AVE_32  (0x05 << 5)

// --- SpO2 Configuration Register Bits (REG_SPO2_CONFIG, 0x0A) ---
// ADC Range (A_ADC_RGE)
#define SPO2_ADC_RGE_2048   (0x00 << 5)
#define SPO2_ADC_RGE_4096   (0x01 << 5)
// Sample Rate (SR)
#define SPO2_SR_100HZ       (0x03 << 2)
// Pulse Width (PW)
#define SPO2_PW_411US       (0x03 << 0)

// --- Data Structure for readings ---
typedef struct {
    uint32_t red_led;
    uint32_t ir_led;
} MAX30102_Data_t;

// --- Function Prototypes ---
void MAX30102_Init(void);
void MAX30102_Reset(void);
uint8_t MAX30102_ReadPartID(void);
uint8_t MAX30102_ReadFIFO(MAX30102_Data_t *data);


#endif /* MAX30102_H_ */
