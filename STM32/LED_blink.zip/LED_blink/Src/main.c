#include <stdio.h>
#include <stdint.h>
#include "stm324fxx.h"
// Define the pin number for the LED (PA5)
// Define the pin number for the LED (PA5)
#define LEDPin    5
// Define the pin number for the Analog Input (PA0 is ADC1 Channel 0)
#define TempSensorPin 0
// Define the pin number for the Switch/Button (PC13 - for checking button state)
#define SwitchPin 13

// Function prototypes to resolve implicit declaration warnings
void delay_ms(void);
void PinsInit(void);
void ADC1Init(void);
uint16_t ADC1_Read(void);

// Simple software delay function
void delay_ms(void)
{
    // Simple blocking delay loop for calibration (Increased from 164000 to 328000 based on your input)
    for (uint32_t i = 0; i < 164000 * 2; i++);
}

/**
 * @brief Initializes GPIO Pins for LED (PA5, Output) and Switch (PC13, Input).
 */
void PinsInit(void)
{
    // Enable the clock for GPIO Port A (bit 0 in AHB1ENR)
	RCC->AHB1ENR |= (1 << 0);
    // Enable the clock for GPIO Port C (bit 2 in AHB1ENR)
	RCC->AHB1ENR |= (1 << 2);

    // --- Configure LED (PA5) as Output ---
    // Clear the Mode Register bits (10 and 11) for Pin 5
	GPIOA->MODER &= ~(0x3 << (LEDPin * 2));
    // Set Pin 5 to General Purpose Output Mode (01)
	GPIOA->MODER |= (1 << (LEDPin * 2));

    // --- Configure Button (PC13) as Input ---
    // Clear the Mode Register bits (26 and 27) for Pin 13
    // Mode '00' is Input, which is the default after clearing
	GPIOC->MODER &= ~(0x3 << (SwitchPin * 2));
}

/**
 * @brief Initializes ADC1 for single-channel, single-conversion mode on Channel 0 (PA0).
 */
// CORRECTED: Function name should match the prototype: ADC1_Init -> ADC1Init
void ADC1Init(void)
{
    // Enable clock for GPIO Port A (bit 0 in AHB1ENR) - done in PinsInit, but harmless to repeat
	RCC->AHB1ENR |= (1 << 0);
    // Enable clock for ADC1 (bit 8 in APB2ENR)
    RCC->APB2ENR |= (1 << 8);

    // --- Configure GPIO Pin PA0 for Analog Mode ---
    // Clear the Mode Register bits (0 and 1) for Pin 0
    GPIOA->MODER &= ~(0x3 << (TempSensorPin * 2));
    // Set Pin 0 to Analog Mode (11)
    GPIOA->MODER |= (0x3 << (TempSensorPin * 2));

    // --- Configure ADC1 ---
    // Clear the sequence register (SQR3) to set the first and only conversion
    ADC1->SQR3 = 0;
    // Set SQR3 L[3:0] (bits 0-3) to 0, selecting Channel 0 (PA0) for the 1st conversion
    ADC1->SQR3 |= (TempSensorPin << 0);

    // Set L[3:0] in SQR1 (bits 20-23) to 0 to define 1 conversion in the sequence
    ADC1->SQR1 &= ~(0xF << 20);

    // Set ADC prescaler to /8 (bits 16-17 in CCR). 84MHz / 8 = 10.5MHz (safe)
    ADC->CCR |= (0x2 << 16);

    // Set resolution to 12-bit (RES[1:0] in CR1 is 00) - default is 12-bit
    ADC1->CR1 &= ~(0x3 << 24);

    // Enable the ADC (ADON bit 0 in CR2)
    ADC1->CR2 |= (1 << 0);
}

/**
 * @brief Reads the raw 12-bit value from ADC1.
 * @return uint16_t The raw ADC conversion value (0-4095).
 */
uint16_t ADC1_Read(void)
{
    // Start the conversion (SWSTART bit 30 in CR2)
    ADC1->CR2 |= (1 << 30);

    // Wait for the conversion to finish (EOC bit 1 in SR)
    // Loop until the EOC bit is set
    while (!(ADC1->SR & (1 << 1)));

    // Return the result from the 12-bit data register (DR)
    return (uint16_t)ADC1->DR;
}


int main(void)
{
    // Initialize the ADC (PA0 Analog mode)
    ADC1Init();
    // Initialize GPIO pins (PA5 Output, PC13 Input)
    PinsInit();

    // --- Infinite Loop ---
    while(1)
    {
        uint16_t adc_value = ADC1_Read(); // Read the ADC value

    	uint32_t scaled_temp_x100 = (adc_value * 33000) / 4096;

    	// Extract Integer and Fractional Parts
    	int temp_int = scaled_temp_x100 / 100; // Integer part
    	int temp_frac = scaled_temp_x100 % 100; // Fractional part (00 to 99)
    	// Print using standard %d, which doesn't require floating-point support
    	printf("Temperature: %d.%02d C\n", temp_int, temp_frac);
    	// --- LM35 Temperature Calculation ---
    	            float voltage_mv = (float)adc_value * (3300.0f / 4096.0f);
    	            float temperature_c = voltage_mv / 10.0f; // LM35: 10mV per degree C

    	            printf("Temperature: %.2f C\n", adc_value);
        // --- Button Check (Active Low Logic) ---
        // If (PC13 is HIGH), the button is RELEASED
        // If (PC13 is LOW), the button is PRESSED

        if (GPIOC->IDR & (1 << SwitchPin)) // Check if pin is HIGH (Button is RELEASED/Open)
        {
            // Action for RELEASED state
            // Turn LED OFF (Clear bit 5)
            GPIOA->ODR &= ~(1 << LEDPin);
            printf("Switch Released\n");
            delay_ms();
        }
        else // Pin is LOW (Button is PRESSED/Closed)
        {
            // Action for PRESSED state
            // Turn LED ON (Set bit 5)
            GPIOA->ODR |= (1 << LEDPin);
            printf("Switch Pressed\n");
            delay_ms();
        }
    }
}
